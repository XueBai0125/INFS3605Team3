package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

public class MainActivity extends AppCompatActivity {

    EditText rp_email, rp_name, rp_password, rp_confirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rp_email = (EditText) findViewById(R.id.rp_email);
        rp_name = (EditText) findViewById(R.id.rp_name);
        rp_password = (EditText) findViewById(R.id.rp_password);
        rp_confirm = (EditText) findViewById(R.id.rp_confirm);
    }

    public void createNewAccount(View v) {
        final String email = rp_email.getText().toString();
        final String name = rp_name.getText().toString();
        final String password = rp_password.getText().toString();
        String confirm = rp_confirm.getText().toString();

        if (email.isEmpty()) {
            Toast.makeText(this, "Please Enter Email", Toast.LENGTH_SHORT).show();
            return;
        }

        if (name.isEmpty()) {
            Toast.makeText(this, "Please Enter Name", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Please Enter Password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!(password.equals(confirm))) {
            Toast.makeText(this, "Confirm Password", Toast.LENGTH_SHORT).show();
            return;
        }

        final FirebaseAuth mAuth = FirebaseAuth.getInstance();
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(MainActivity.this, "Account Created!", Toast.LENGTH_SHORT).show();
                    FirebaseUser user = mAuth.getCurrentUser();
                    UserProfileChangeRequest request = new UserProfileChangeRequest.Builder()
                            .setDisplayName(name).build();
                    user.updateProfile(request);
                    mAuth.signOut();
                    mAuth.signInWithEmailAndPassword(email, password);
                    finish();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(MainActivity.this, "Fail:"+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}